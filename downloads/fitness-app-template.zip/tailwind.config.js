/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'media', // follows the system light/dark preference
  theme: {
    extend: {
      colors: {
        charcoal: { DEFAULT: '#1A1A1A', deep: '#121212', soft: '#222222', line: '#2E2E2C' },
        cream: { DEFAULT: '#F4F1EA', soft: '#ECE8DF', line: '#DAD4C7' },
        clay: { DEFAULT: '#C0795C', soft: '#D08F73', deep: '#A9613F' }
      },
      fontFamily: {
        serif: ['"Iowan Old Style"', '"Palatino Linotype"', 'Georgia', 'Cambria', '"Times New Roman"', 'serif'],
        sans: ['system-ui', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', 'sans-serif']
      },
      letterSpacing: { tightish: '-0.015em' },
      borderRadius: { xl2: '1.25rem' }
    }
  },
  plugins: []
}

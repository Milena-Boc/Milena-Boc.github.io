import { useEffect, useRef, useState } from 'react'
import { Play, Pause, RotateCcw } from 'lucide-react'
import { Card, Label, Pill, Button, Field, inputClass } from './ui'

// One shared AudioContext, created on the first tap (browsers require a gesture).
let ctx
function beep(freq = 880, ms = 160) {
  try {
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)()
    const o = ctx.createOscillator()
    const g = ctx.createGain()
    o.frequency.value = freq
    o.connect(g)
    g.connect(ctx.destination)
    g.gain.setValueAtTime(0.2, ctx.currentTime)
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + ms / 1000)
    o.start()
    o.stop(ctx.currentTime + ms / 1000)
  } catch {
    /* audio unavailable */
  }
}

const fmt = (s) => {
  const m = Math.floor(Math.abs(s) / 60)
  const r = Math.floor(Math.abs(s) % 60)
  return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`
}

export default function Timer({ preset, title }) {
  const [mode, setMode] = useState(preset?.mode || 'amrap')
  const [minutes, setMinutes] = useState(preset?.minutes || preset?.cap || 12)
  const [interval, setIntervalSec] = useState(preset?.interval || 60)
  const [elapsed, setElapsed] = useState(0)
  const [running, setRunning] = useState(false)
  const startRef = useRef(0)
  const baseRef = useRef(0)
  const lastBeep = useRef(-1)

  useEffect(() => {
    if (!preset) return
    setMode(preset.mode)
    setMinutes(preset.minutes || preset.cap || 12)
    setIntervalSec(preset.interval || 60)
    setElapsed(0)
    setRunning(false)
  }, [preset])

  const total = minutes * 60
  const done = elapsed >= total

  useEffect(() => {
    if (!running) return
    const id = setInterval(() => {
      const e = baseRef.current + (Date.now() - startRef.current) / 1000
      setElapsed(Math.min(e, total))
      const sec = Math.floor(e)
      if (sec !== lastBeep.current) {
        if (mode === 'emom' && sec > 0 && sec % interval === 0 && sec < total) {
          beep(880)
          lastBeep.current = sec
        }
        if (total - sec <= 3 && total - sec > 0) {
          beep(660, 120)
          lastBeep.current = sec
        }
      }
      if (e >= total) {
        beep(440, 600)
        setRunning(false)
      }
    }, 200)
    return () => clearInterval(id)
  }, [running, mode, interval, total])

  const toggle = () => {
    if (done) return
    if (running) {
      baseRef.current = elapsed
      setRunning(false)
    } else {
      beep(1040, 90)
      startRef.current = Date.now()
      setRunning(true)
    }
  }
  const reset = () => {
    setRunning(false)
    setElapsed(0)
    baseRef.current = 0
    lastBeep.current = -1
  }

  let big = fmt(elapsed)
  let sub = `Cap ${minutes} min`
  if (mode === 'amrap') {
    big = fmt(total - elapsed)
    sub = `${minutes} minute AMRAP`
  }
  if (mode === 'emom') {
    const round = Math.min(Math.floor(elapsed / interval) + 1, Math.ceil(total / interval))
    big = fmt(interval - (elapsed % interval))
    sub = `Round ${round} of ${Math.ceil(total / interval)} · every ${interval === 60 ? 'minute' : `${interval / 60} minutes`}`
  }

  return (
    <Card>
      <Label>Timer{title ? ` · ${title}` : ''}</Label>
      <div className="mt-3 flex gap-2">
        {[
          ['amrap', 'AMRAP'],
          ['emom', 'EMOM'],
          ['fortime', 'For time']
        ].map(([id, l]) => (
          <Pill key={id} active={mode === id} onClick={() => { setMode(id); reset() }}>{l}</Pill>
        ))}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <Field label={mode === 'fortime' ? 'Time cap (min)' : 'Minutes'}>
          <input className={inputClass} type="number" inputMode="numeric" min="1" value={minutes}
            onChange={(e) => { setMinutes(Math.max(1, +e.target.value || 1)); reset() }} />
        </Field>
        {mode === 'emom' && (
          <Field label="Interval (sec)">
            <input className={inputClass} type="number" inputMode="numeric" min="10" step="10" value={interval}
              onChange={(e) => { setIntervalSec(Math.max(10, +e.target.value || 60)); reset() }} />
          </Field>
        )}
      </div>
      <p className={`mt-6 text-center font-serif text-7xl tabular-nums tracking-tightish ${done ? 'text-clay' : ''}`}>{done ? 'Time' : big}</p>
      <p className="mt-1 text-center text-sm text-charcoal/60 dark:text-cream/60">{sub}</p>
      <div className="mt-6 flex justify-center gap-3">
        <Button onClick={toggle} disabled={done} className="min-w-[120px]">
          {running ? <Pause size={18} /> : <Play size={18} />} {running ? 'Pause' : elapsed > 0 ? 'Resume' : 'Start'}
        </Button>
        <Button variant="quiet" onClick={reset}><RotateCcw size={18} /> Reset</Button>
      </div>
    </Card>
  )
}

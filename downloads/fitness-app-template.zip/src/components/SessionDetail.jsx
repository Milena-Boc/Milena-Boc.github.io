import { useState } from 'react'
import { Timer as TimerIcon, Check } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { formatLoad, fromDisplay, currentPR } from '../lib/prescription'
import { PHASE_LABEL } from '../lib/cycle'
import { Card, Label, Title, Muted, Button, List, inputClass } from './ui'

const RATINGS = [
  ['easy', 'Easy'],
  ['grind', 'Grind'],
  ['missed', 'Missed']
]

function LiftRow({ lift, date, session, units, progression }) {
  const { state, dispatch } = useApp()
  const [w, setW] = useState('')
  const [r, setR] = useState('')
  const top = session.topSets?.[lift.lift]
  const rating = session.ratings?.[lift.lift]
  const hasPR = currentPR(state.prs, lift.lift)

  const log = () => {
    const kg = fromDisplay(parseFloat(w), units)
    const reps = parseInt(r, 10)
    if (!kg || !reps) return
    dispatch({ type: 'logTopSet', date, lift: lift.lift, kg, reps })
    setW('')
    setR('')
  }

  return (
    <li className="border-t border-cream-line py-4 first:border-t-0 first:pt-0 dark:border-charcoal-line">
      <div className="flex items-baseline justify-between gap-3">
        <p className="font-serif text-lg">
          {lift.name}
          {lift.kind === 'priority' && <span className="ml-2 align-middle text-[11px] uppercase tracking-[0.14em] text-clay">Priority</span>}
        </p>
        <p className="whitespace-nowrap text-sm tabular-nums">
          {lift.sets} × {lift.reps}
        </p>
      </div>
      <p className="mt-1 text-sm text-charcoal/60 dark:text-cream/60">
        {hasPR ? <>Working weight <span className="font-medium text-charcoal dark:text-cream">{formatLoad(lift.kg, units)}</span> · {Math.round(lift.pct * 100)}% of PR</> : 'Add a PR in the PR log to get a prescribed weight.'}
      </p>
      {top ? (
        <p className="mt-2 text-sm text-clay-deep dark:text-clay-soft">Top set logged: {formatLoad(top.kg, units)} × {top.reps}</p>
      ) : (
        <div className="mt-3 flex gap-2">
          <input aria-label={`${lift.name} top set weight`} className={inputClass} inputMode="decimal" placeholder={`Top set (${units})`} value={w} onChange={(e) => setW(e.target.value)} />
          <input aria-label={`${lift.name} top set reps`} className={`${inputClass} max-w-[84px]`} inputMode="numeric" placeholder="Reps" value={r} onChange={(e) => setR(e.target.value)} />
          <Button variant="quiet" onClick={log}>Log</Button>
        </div>
      )}
      {progression && (
        <div className="mt-3 flex items-center gap-2">
          <span className="text-xs text-charcoal/50 dark:text-cream/50">How did it feel?</span>
          {RATINGS.map(([id, l]) => (
            <button
              key={id}
              type="button"
              disabled={!!rating && rating !== id}
              onClick={() => !rating && dispatch({ type: 'rateLift', date, lift: lift.lift, rating: id, kind: lift.kind })}
              className={`rounded-full px-3 py-1.5 text-xs transition-colors ${
                rating === id ? 'bg-clay text-white' : 'bg-cream-soft text-charcoal/70 disabled:opacity-30 dark:bg-charcoal-line dark:text-cream/70'
              }`}
            >
              {l}
            </button>
          ))}
        </div>
      )}
    </li>
  )
}

export default function SessionDetail({ plan, onOpenTimer }) {
  const { state, dispatch } = useApp()
  const { units, progression } = state.profile
  const session = state.sessions[plan.date] || {}

  return (
    <div className="space-y-4">
      <Card>
        <Label>{plan.title}</Label>
        <Title className="mt-1">{plan.wod ? plan.wod.name : plan.focus}</Title>
        <div className="mt-2 flex flex-wrap gap-2 text-xs">
          {plan.deload && <span className="rounded-full bg-clay/15 px-3 py-1 text-clay-deep dark:text-clay-soft">Deload week · lighter on purpose</span>}
          {plan.retest && <span className="rounded-full bg-clay/15 px-3 py-1 text-clay-deep dark:text-clay-soft">Re-test week · try a new top set</span>}
          {plan.cycle && plan.cycle.phase === 'luteal' && <span className="rounded-full bg-cream-soft px-3 py-1 dark:bg-charcoal-line">{PHASE_LABEL.luteal} · volume eased</span>}
        </div>
        <div className="mt-4 flex gap-2">
          {!session.started && plan.type !== 'rest' && <Button onClick={() => dispatch({ type: 'startSession', date: plan.date })}>Start session</Button>}
          {session.started && !session.finished && <Button onClick={() => dispatch({ type: 'finishSession', date: plan.date })}><Check size={18} /> Finish session</Button>}
          {session.finished && <p className="flex items-center gap-2 text-sm text-clay-deep dark:text-clay-soft"><Check size={18} /> Session complete</p>}
        </div>
      </Card>

      <Card>
        <Label>Warm-up</Label>
        <div className="mt-3"><List items={plan.warmup} /></div>
      </Card>

      {plan.type === 'strength' && (
        <Card>
          <Label>Main work</Label>
          <ul className="mt-3">
            {plan.lifts.map((l) => (
              <LiftRow key={l.lift} lift={l} date={plan.date} session={session} units={units} progression={progression} />
            ))}
          </ul>
        </Card>
      )}

      {plan.wod && (
        <Card>
          <Label>Main work</Label>
          <p className="mt-2 font-serif text-lg">{plan.wod.format}</p>
          <div className="mt-3"><List items={plan.wod.work} /></div>
          {plan.wod.load && (
            <p className="mt-3 text-sm text-charcoal/70 dark:text-cream/70">
              {plan.wod.load.label}: <span className="font-medium">{plan.wod.load.kg ? formatLoad(plan.wod.load.kg, units) : 'add a PR for a weight'}</span>
            </p>
          )}
          <Muted className="mt-1">Intensity: {plan.wod.intensity}</Muted>
          <Button variant="quiet" className="mt-4" onClick={() => onOpenTimer(plan.wod.timer, plan.wod.name)}>
            <TimerIcon size={18} /> Open the timer
          </Button>
        </Card>
      )}

      {plan.type === 'cardio' && (
        <Card>
          <Label>Main work</Label>
          <p className="mt-2 font-serif text-lg">{plan.cardio.title}</p>
          <Muted className="mt-1">{plan.cardio.detail}</Muted>
        </Card>
      )}

      <Card>
        <Label>Cool-down and mobility</Label>
        <div className="mt-3"><List items={plan.cooldown} /></div>
      </Card>
    </div>
  )
}

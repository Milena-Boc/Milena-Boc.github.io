import { shortDate } from '../lib/date'

// A small, dependency-free SVG line chart for one metric over time.
export default function LineChart({ points, unit = '' }) {
  if (!points.length) return <p className="py-10 text-center text-sm text-charcoal/50 dark:text-cream/50">No entries yet.</p>
  const W = 320, H = 170, pl = 36, pr = 12, pt = 14, pb = 26
  const vals = points.map((p) => p.value)
  let min = Math.min(...vals), max = Math.max(...vals)
  if (min === max) { min -= 1; max += 1 }
  const padV = (max - min) * 0.15
  min -= padV; max += padV
  const x = (i) => pl + (points.length === 1 ? (W - pl - pr) / 2 : (i / (points.length - 1)) * (W - pl - pr))
  const y = (v) => pt + (1 - (v - min) / (max - min)) * (H - pt - pb)
  const line = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`).join(' ')
  const area = `${line} L${x(points.length - 1).toFixed(1)},${H - pb} L${x(0).toFixed(1)},${H - pb} Z`
  const ticks = [min + (max - min) * 0.15, (min + max) / 2, max - (max - min) * 0.15]
  const last = points[points.length - 1]
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`Chart, latest ${last.value} ${unit}`}>
      {ticks.map((t) => (
        <g key={t}>
          <line x1={pl} x2={W - pr} y1={y(t)} y2={y(t)} className="stroke-cream-line dark:stroke-charcoal-line" strokeWidth="1" />
          <text x={pl - 6} y={y(t) + 4} textAnchor="end" className="fill-charcoal/50 dark:fill-cream/50" fontSize="10">{t.toFixed(1)}</text>
        </g>
      ))}
      <path d={area} className="fill-clay/10" />
      <path d={line} fill="none" className="stroke-clay" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {points.map((p, i) => (
        <circle key={p.date} cx={x(i)} cy={y(p.value)} r={i === points.length - 1 ? 4.5 : 2.5} className="fill-clay" />
      ))}
      <text x={pl} y={H - 6} fontSize="10" className="fill-charcoal/50 dark:fill-cream/50">{shortDate(points[0].date)}</text>
      {points.length > 1 && (
        <text x={W - pr} y={H - 6} fontSize="10" textAnchor="end" className="fill-charcoal/50 dark:fill-cream/50">{shortDate(last.date)}</text>
      )}
    </svg>
  )
}

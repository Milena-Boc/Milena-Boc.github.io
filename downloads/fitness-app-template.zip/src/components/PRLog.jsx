import { useState } from 'react'
import { X } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { LIFTS } from '../data/profile'
import { formatLoad, fromDisplay, currentPR } from '../lib/prescription'
import { todayISO, shortDate } from '../lib/date'
import { Card, Label, Button, Field, inputClass, Muted } from './ui'

export default function PRLog() {
  const { state, dispatch } = useApp()
  const units = state.profile.units
  const all = { ...LIFTS, ...state.customLifts }
  const [lift, setLift] = useState('backSquat')
  const [value, setValue] = useState('')
  const [date, setDate] = useState(todayISO())
  const [custom, setCustom] = useState('')
  const [open, setOpen] = useState(null)

  const add = () => {
    const kg = fromDisplay(parseFloat(value), units)
    if (!kg) return
    dispatch({ type: 'addPR', lift, kg, date })
    setValue('')
  }
  const addCustom = () => {
    const name = custom.trim()
    if (!name) return
    const id = `custom-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`
    dispatch({ type: 'addCustomLift', id, name })
    setLift(id)
    setCustom('')
  }

  return (
    <div className="space-y-4">
      <Card>
        <Label>Log a personal record</Label>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <Field label="Lift">
            <select className={inputClass} value={lift} onChange={(e) => setLift(e.target.value)}>
              {Object.entries(all).map(([id, name]) => <option key={id} value={id}>{name}</option>)}
            </select>
          </Field>
          <Field label={`One-rep max (${units})`}>
            <input className={inputClass} inputMode="decimal" value={value} onChange={(e) => setValue(e.target.value)} placeholder="0" />
          </Field>
          <Field label="Date">
            <input className={inputClass} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <div className="flex items-end"><Button className="w-full" onClick={add}>Save PR</Button></div>
        </div>
        <div className="mt-4 flex gap-2">
          <input aria-label="New custom lift" className={inputClass} placeholder="Add a custom lift" value={custom} onChange={(e) => setCustom(e.target.value)} />
          <Button variant="quiet" onClick={addCustom}>Add</Button>
        </div>
        <Muted className="mt-3">Every prescribed weight recalculates from these. Logging a top set in a session updates them automatically when you beat them.</Muted>
      </Card>

      <Card>
        <Label>Your lifts</Label>
        <ul className="mt-2">
          {Object.entries(all).map(([id, name]) => {
            const pr = currentPR(state.prs, id)
            const history = state.prs[id] || []
            return (
              <li key={id} className="border-t border-cream-line py-3 first:border-t-0 dark:border-charcoal-line">
                <button type="button" className="flex w-full items-baseline justify-between text-left" onClick={() => setOpen(open === id ? null : id)}>
                  <span className="font-serif text-[17px]">{name}</span>
                  <span className="tabular-nums text-sm">{pr ? formatLoad(pr, units) : '—'}</span>
                </button>
                {open === id && (
                  <ul className="mt-2 space-y-1">
                    {history.length === 0 && <Muted>No entries yet.</Muted>}
                    {[...history].reverse().map((e, i) => (
                      <li key={`${e.date}-${i}`} className="flex items-center justify-between text-sm text-charcoal/70 dark:text-cream/70">
                        <span>{shortDate(e.date)}{e.estimated ? ' · estimated from a top set' : ''}</span>
                        <span className="flex items-center gap-2 tabular-nums">
                          {formatLoad(e.kg, units)}
                          <button type="button" aria-label="Remove entry" onClick={() => dispatch({ type: 'removePR', lift: id, index: history.length - 1 - i })}>
                            <X size={14} />
                          </button>
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            )
          })}
        </ul>
      </Card>
    </div>
  )
}

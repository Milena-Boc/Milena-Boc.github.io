import { Home, Dumbbell, Apple, TrendingUp, Settings } from 'lucide-react'

export const TABS = [
  { id: 'home', label: 'Today', Icon: Home },
  { id: 'workouts', label: 'Train', Icon: Dumbbell },
  { id: 'nutrition', label: 'Eat', Icon: Apple },
  { id: 'progress', label: 'Progress', Icon: TrendingUp },
  { id: 'settings', label: 'Settings', Icon: Settings }
]

export default function TabBar({ tab, setTab }) {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-20 border-t border-cream-line bg-cream/95 backdrop-blur dark:border-charcoal-line dark:bg-charcoal-deep/95"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <ul className="mx-auto flex max-w-md justify-between px-2">
        {TABS.map(({ id, label, Icon }) => {
          const active = tab === id
          return (
            <li key={id} className="flex-1">
              <button
                type="button"
                onClick={() => setTab(id)}
                aria-current={active ? 'page' : undefined}
                className={`flex w-full flex-col items-center gap-1 py-2.5 text-[11px] ${
                  active ? 'text-clay-deep dark:text-clay-soft' : 'text-charcoal/50 dark:text-cream/50'
                }`}
              >
                <Icon size={21} strokeWidth={active ? 2 : 1.6} />
                {label}
              </button>
            </li>
          )
        })}
      </ul>
    </nav>
  )
}

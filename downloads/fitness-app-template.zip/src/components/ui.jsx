export function Card({ children, className = '' }) {
  return (
    <section className={`rounded-xl2 border border-cream-line bg-white/70 p-5 dark:border-charcoal-line dark:bg-charcoal-soft ${className}`}>
      {children}
    </section>
  )
}

export function Label({ children, className = '' }) {
  return <p className={`text-[11px] font-medium uppercase tracking-[0.18em] text-clay-deep dark:text-clay-soft ${className}`}>{children}</p>
}

export function Title({ children, className = '' }) {
  return <h2 className={`font-serif text-2xl leading-tight tracking-tightish ${className}`}>{children}</h2>
}

export function Muted({ children, className = '' }) {
  return <p className={`text-sm text-charcoal/60 dark:text-cream/60 ${className}`}>{children}</p>
}

export function Button({ children, variant = 'primary', className = '', ...props }) {
  const styles = {
    primary: 'bg-clay text-white hover:bg-clay-deep',
    quiet: 'bg-cream-soft text-charcoal hover:bg-cream-line dark:bg-charcoal-line dark:text-cream',
    ghost: 'text-clay-deep hover:underline dark:text-clay-soft'
  }
  return (
    <button
      type="button"
      className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-full px-5 text-sm font-medium transition-colors disabled:opacity-40 ${styles[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  )
}

export function Pill({ children, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`whitespace-nowrap rounded-full px-4 py-2 text-sm transition-colors ${
        active ? 'bg-charcoal text-cream dark:bg-cream dark:text-charcoal' : 'bg-cream-soft text-charcoal/70 dark:bg-charcoal-soft dark:text-cream/70'
      }`}
    >
      {children}
    </button>
  )
}

export function Bar({ label, value, target, unit = 'g', extra = 0 }) {
  const goal = target + extra
  const pct = goal > 0 ? Math.min(100, (value / goal) * 100) : 0
  const left = Math.max(0, Math.round(goal - value))
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-sm">
        <span className="font-medium">{label}</span>
        <span className="tabular-nums text-charcoal/60 dark:text-cream/60">
          {Math.round(value)} / {Math.round(goal)} {unit} · {left} left
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-cream-soft dark:bg-charcoal-line">
        <div className="h-full rounded-full bg-clay transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

export function Field({ label, children }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block text-charcoal/60 dark:text-cream/60">{label}</span>
      {children}
    </label>
  )
}

export const inputClass =
  'w-full rounded-xl border border-cream-line bg-white px-3 py-2.5 text-base text-charcoal outline-none focus:border-clay dark:border-charcoal-line dark:bg-charcoal-deep dark:text-cream'

export function List({ items }) {
  return (
    <ul className="space-y-2">
      {items.map((x) => (
        <li key={x} className="flex gap-3 text-[15px] leading-snug">
          <span className="mt-2 h-1 w-1 flex-none rounded-full bg-clay" />
          <span>{x}</span>
        </li>
      ))}
    </ul>
  )
}

import { useState } from 'react'
import { Timer as TimerIcon } from 'lucide-react'
import { WODS } from '../data/wods'
import { useApp } from '../context/AppContext'
import { formatLoad, prescribe } from '../lib/prescription'
import { Card, Label, Button, List, Muted } from './ui'

export default function WodLibrary({ onOpenTimer }) {
  const { state } = useApp()
  const [open, setOpen] = useState(null)
  return (
    <Card>
      <Label>Library · {WODS.length} workouts</Label>
      <ul className="mt-2">
        {WODS.map((w) => (
          <li key={w.id} className="border-t border-cream-line py-3 first:border-t-0 dark:border-charcoal-line">
            <button type="button" className="flex w-full items-baseline justify-between gap-3 text-left" onClick={() => setOpen(open === w.id ? null : w.id)}>
              <span className="font-serif text-[17px]">{w.name}</span>
              <span className="text-right text-xs text-charcoal/50 dark:text-cream/50">{w.format}</span>
            </button>
            {open === w.id && (
              <div className="mt-3 space-y-3">
                <List items={w.work} />
                {w.load && (
                  <Muted>
                    {w.load.label}: {(() => {
                      const kg = prescribe(state.prs, w.load.lift, w.load.pct)
                      return kg ? formatLoad(kg, state.profile.units) : 'add a PR for a weight'
                    })()}
                  </Muted>
                )}
                <Button variant="quiet" onClick={() => onOpenTimer(w.timer, w.name)}><TimerIcon size={18} /> Time it</Button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </Card>
  )
}

import { Share } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { Button, Label } from './ui'

export default function Welcome() {
  const { dispatch } = useApp()
  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-charcoal/40 p-4 backdrop-blur-sm sm:items-center">
      <div className="w-full max-w-md rounded-xl2 bg-cream p-6 shadow-xl dark:bg-charcoal-soft" role="dialog" aria-labelledby="welcome-title">
        <Label>Fitness &amp; Nutrition</Label>
        <h1 id="welcome-title" className="mt-2 font-serif text-3xl leading-tight tracking-tightish">Your training, macros and progress, in one place.</h1>
        <p className="mt-3 text-[15px] leading-relaxed text-charcoal/70 dark:text-cream/70">
          Today's session is chosen for you, weights come from your own records, and everything stays on this phone.
          No account, no cloud.
        </p>
        <div className="mt-6 grid gap-2">
          <Button onClick={() => dispatch({ type: 'welcome', withSample: true })}>Explore with sample data</Button>
          <Button variant="quiet" onClick={() => dispatch({ type: 'welcome', withSample: false })}>Start fresh</Button>
        </div>
        <p className="mt-5 flex items-center gap-2 text-xs text-charcoal/60 dark:text-cream/60">
          <Share size={14} /> On iPhone, open this in Safari, tap Share, then Add to Home Screen.
        </p>
      </div>
    </div>
  )
}

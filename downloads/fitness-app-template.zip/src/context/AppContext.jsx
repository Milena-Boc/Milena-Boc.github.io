import { createContext, useContext, useEffect, useMemo, useReducer } from 'react'
import { DEFAULT_PROFILE, DEFAULT_TARGETS } from '../data/profile'
import { sampleData } from '../data/sample'
import { load, save, clear } from '../lib/storage'
import { todayISO } from '../lib/date'
import { epley, currentPR } from '../lib/prescription'
import { applyStrengthRating, applyHypertrophyRating, effective } from '../lib/progression'
import { addDays } from '../lib/date'

const AppContext = createContext(null)

function initialState() {
  return {
    version: 1,
    welcomed: false,
    sample: false,
    profile: { ...DEFAULT_PROFILE, blockStart: todayISO() },
    targets: structuredClone(DEFAULT_TARGETS),
    prs: {},
    customLifts: {},
    sessions: {},
    progress: { lifts: {}, priority: { reps: 8, loadAdj: 0 } },
    meals: {},
    body: [],
    photos: [],
    overrides: {}
  }
}

function hydrate() {
  const saved = load()
  if (!saved) return initialState()
  const base = initialState()
  return { ...base, ...saved, profile: { ...base.profile, ...saved.profile }, targets: { ...base.targets, ...saved.targets } }
}

let mealSeq = 0
const uid = () => `${Date.now().toString(36)}${(mealSeq++).toString(36)}`

function reducer(state, a) {
  switch (a.type) {
    case 'welcome': {
      if (a.withSample) return { ...state, ...sampleData(), welcomed: true, sample: true }
      return { ...state, welcomed: true }
    }
    case 'loadSample':
      return { ...state, ...sampleData(), sample: true, welcomed: true }
    case 'clearSample':
      return { ...initialState(), welcomed: true, profile: state.profile, targets: state.targets }
    case 'reset':
      clear()
      return initialState()
    case 'setProfile':
      return { ...state, profile: { ...state.profile, ...a.patch } }
    case 'setTargets':
      return { ...state, targets: { ...state.targets, [a.kind]: { ...state.targets[a.kind], ...a.patch } } }
    case 'setOverride': {
      const overrides = { ...state.overrides }
      if (a.value) overrides[a.date] = a.value
      else delete overrides[a.date]
      return { ...state, overrides }
    }
    case 'addPR': {
      const list = [...(state.prs[a.lift] || []), { date: a.date, kg: a.kg }]
      list.sort((x, y) => x.date.localeCompare(y.date))
      return { ...state, prs: { ...state.prs, [a.lift]: list } }
    }
    case 'removePR': {
      const list = (state.prs[a.lift] || []).filter((_, i) => i !== a.index)
      return { ...state, prs: { ...state.prs, [a.lift]: list } }
    }
    case 'addCustomLift':
      return { ...state, customLifts: { ...state.customLifts, [a.id]: a.name } }
    case 'startSession':
      return { ...state, sessions: { ...state.sessions, [a.date]: { ...(state.sessions[a.date] || {}), started: true } } }
    case 'finishSession':
      return { ...state, sessions: { ...state.sessions, [a.date]: { ...(state.sessions[a.date] || {}), started: true, finished: true } } }
    case 'logTopSet': {
      const s = state.sessions[a.date] || {}
      const topSets = { ...(s.topSets || {}), [a.lift]: { kg: a.kg, reps: a.reps } }
      let prs = state.prs
      const est = epley(a.kg, a.reps)
      const pr = currentPR(state.prs, a.lift)
      if (!pr || est > pr) {
        prs = { ...prs, [a.lift]: [...(prs[a.lift] || []), { date: a.date, kg: +est.toFixed(1), estimated: true }] }
      }
      return { ...state, prs, sessions: { ...state.sessions, [a.date]: { ...s, topSets } } }
    }
    case 'rateLift': {
      const s = state.sessions[a.date] || {}
      const prev = s.ratings?.[a.lift]
      const ratings = { ...(s.ratings || {}), [a.lift]: a.rating }
      let progress = state.progress
      if (!prev) {
        // Ratings apply once per lift per session.
        const from = addDays(a.date, 1)
        if (a.kind === 'priority') {
          const cur = effective(progress.priority, a.date, { reps: 8, loadAdj: 0 })
          progress = { ...progress, priority: { value: applyHypertrophyRating(cur, a.rating), prev: cur, from } }
        } else {
          const cur = effective(progress.lifts?.[a.lift], a.date, 0)
          progress = { ...progress, lifts: { ...progress.lifts, [a.lift]: { value: applyStrengthRating(cur, a.rating), prev: cur, from } } }
        }
      }
      return { ...state, progress, sessions: { ...state.sessions, [a.date]: { ...s, ratings } } }
    }
    case 'addMeal': {
      const day = [...(state.meals[a.date] || []), { id: uid(), ...a.meal }]
      return { ...state, meals: { ...state.meals, [a.date]: day } }
    }
    case 'removeMeal': {
      const day = (state.meals[a.date] || []).filter((m) => m.id !== a.id)
      return { ...state, meals: { ...state.meals, [a.date]: day } }
    }
    case 'addBody': {
      const body = [...state.body.filter((b) => b.date !== a.entry.date), a.entry].sort((x, y) => x.date.localeCompare(y.date))
      return { ...state, body }
    }
    case 'removeBody':
      return { ...state, body: state.body.filter((b) => b.date !== a.date) }
    case 'addPhoto': {
      const photos = [...state.photos.filter((p) => p.month !== a.month), { month: a.month, dataUrl: a.dataUrl }]
      photos.sort((x, y) => x.month.localeCompare(y.month))
      return { ...state, photos }
    }
    case 'removePhoto':
      return { ...state, photos: state.photos.filter((p) => p.month !== a.month) }
    default:
      return state
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, hydrate)
  useEffect(() => {
    save(state)
  }, [state])
  const value = useMemo(() => ({ state, dispatch }), [state])
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  return useContext(AppContext)
}

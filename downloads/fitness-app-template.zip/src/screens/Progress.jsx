import { useState } from 'react'
import { X, ImagePlus } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { todayISO, shortDate } from '../lib/date'
import LineChart from '../components/LineChart'
import { Card, Label, Pill, Button, Field, inputClass, Muted } from '../components/ui'

const METRICS = [
  ['weight', 'Weight', 'kg'],
  ['muscle', 'Muscle mass', 'kg'],
  ['fatMass', 'Body-fat mass', 'kg'],
  ['fatPct', 'Body fat', '%'],
  ['visceral', 'Visceral fat', 'level'],
  ['bmi', 'BMI', '']
]

// Downscale a photo on the device before storing it.
function downscale(file, max = 720) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.width, img.height))
      const c = document.createElement('canvas')
      c.width = Math.round(img.width * s)
      c.height = Math.round(img.height * s)
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height)
      URL.revokeObjectURL(img.src)
      resolve(c.toDataURL('image/jpeg', 0.72))
    }
    img.onerror = reject
    img.src = URL.createObjectURL(file)
  })
}

export default function Progress() {
  const { state, dispatch } = useApp()
  const [metric, setMetric] = useState('weight')
  const [form, setForm] = useState({ date: todayISO() })
  const [month, setMonth] = useState(todayISO().slice(0, 7))
  const m = METRICS.find((x) => x[0] === metric)
  const points = state.body.filter((b) => b[metric] != null && b[metric] !== '').map((b) => ({ date: b.date, value: +b[metric] }))

  const save = () => {
    const entry = { date: form.date }
    METRICS.forEach(([k]) => {
      if (form[k] !== undefined && form[k] !== '') entry[k] = +form[k]
    })
    if (Object.keys(entry).length < 2) return
    dispatch({ type: 'addBody', entry })
    setForm({ date: todayISO() })
  }

  const onPhoto = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    const dataUrl = await downscale(file)
    dispatch({ type: 'addPhoto', month, dataUrl })
    e.target.value = ''
  }

  return (
    <div className="space-y-4">
      <header className="px-1 pt-4">
        <Label>Progress</Label>
        <h1 className="mt-2 font-serif text-[34px] leading-tight tracking-tightish">Body composition</h1>
      </header>

      <Card>
        <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-2">
          {METRICS.map(([id, l]) => <Pill key={id} active={metric === id} onClick={() => setMetric(id)}>{l}</Pill>)}
        </div>
        <div className="mt-3"><LineChart points={points} unit={m[2]} /></div>
        {points.length > 0 && (
          <p className="mt-2 text-sm tabular-nums">
            Latest: <strong>{points[points.length - 1].value} {m[2]}</strong>
            {points.length > 1 && (() => {
              const d = +(points[points.length - 1].value - points[0].value).toFixed(1)
              return <span className="text-charcoal/60 dark:text-cream/60"> · {d > 0 ? '+' : ''}{d} since {shortDate(points[0].date)}</span>
            })()}
          </p>
        )}
      </Card>

      <Card>
        <Label>Add a scan or weigh-in</Label>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <Field label="Date">
            <input className={inputClass} type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          </Field>
          {METRICS.map(([k, l, u]) => (
            <Field key={k} label={`${l}${u ? ` (${u})` : ''}`}>
              <input className={inputClass} inputMode="decimal" value={form[k] ?? ''} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
            </Field>
          ))}
        </div>
        <Button className="mt-4" onClick={save}>Save entry</Button>
        <Muted className="mt-3">Fill in only what you measured. A body-composition scan gives you most of these.</Muted>
      </Card>

      {state.body.length > 0 && (
        <Card>
          <Label>Entries</Label>
          <ul className="mt-2">
            {[...state.body].reverse().map((b) => (
              <li key={b.date} className="flex items-center justify-between border-t border-cream-line py-2.5 text-sm first:border-t-0 dark:border-charcoal-line">
                <span>{shortDate(b.date)}</span>
                <span className="flex items-center gap-3 tabular-nums text-charcoal/70 dark:text-cream/70">
                  {b.weight != null && `${b.weight} kg`} {b.fatPct != null && `· ${b.fatPct}%`}
                  <button type="button" aria-label="Remove entry" onClick={() => dispatch({ type: 'removeBody', date: b.date })}><X size={14} /></button>
                </span>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Card>
        <Label>Monthly photos</Label>
        <Muted className="mt-2">Stored on this phone only, downscaled to save space.</Muted>
        <div className="mt-3 flex items-end gap-3">
          <Field label="Month">
            <input className={inputClass} type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
          </Field>
          <label className="inline-flex min-h-[44px] cursor-pointer items-center gap-2 rounded-full bg-cream-soft px-5 text-sm font-medium dark:bg-charcoal-line">
            <ImagePlus size={18} /> Add photo
            <input type="file" accept="image/*" className="sr-only" onChange={onPhoto} />
          </label>
        </div>
        {state.photos.length > 0 && (
          <ul className="mt-4 grid grid-cols-3 gap-2">
            {state.photos.map((p) => (
              <li key={p.month} className="relative">
                <img src={p.dataUrl} alt={`Progress photo, ${p.month}`} className="aspect-[3/4] w-full rounded-xl object-cover" />
                <span className="absolute bottom-1 left-1 rounded-full bg-charcoal/70 px-2 py-0.5 text-[10px] text-cream">{p.month}</span>
                <button type="button" aria-label="Remove photo" className="absolute right-1 top-1 rounded-full bg-charcoal/70 p-1 text-cream" onClick={() => dispatch({ type: 'removePhoto', month: p.month })}>
                  <X size={12} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  )
}

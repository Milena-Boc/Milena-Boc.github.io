import { ArrowRight, Check } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { planFor, dayType } from '../lib/schedule'
import { todayISO, longDate, weekDates, dayLetter, greeting, addDays, daysBetween } from '../lib/date'
import { sumMeals, carryOver } from '../lib/nutrition'
import { PHASE_LABEL } from '../lib/cycle'
import { QUOTES } from '../data/quotes'
import { Card, Label, Title, Bar, Button, Muted } from '../components/ui'

const TYPE_SHORT = { strength: 'Lift', wod: 'WOD', cardio: 'Cardio', rest: 'Rest' }

export default function Home({ go }) {
  const { state, dispatch } = useApp()
  const today = todayISO()
  const plan = planFor(state, today)
  const isTraining = plan.type !== 'rest'
  const targets = state.targets[isTraining ? 'training' : 'rest']
  const yesterday = addDays(today, -1)
  const yType = dayType(state, yesterday) !== 'rest' ? 'training' : 'rest'
  const extra = carryOver(state.targets[yType], state.meals[yesterday] ? sumMeals(state.meals[yesterday]) : null, targets)
  const eaten = sumMeals(state.meals[today])
  const week = weekDates(today, state.profile.weekStart)
  const quote = QUOTES[Math.abs(daysBetween('2024-01-01', today)) % QUOTES.length]
  const name = state.profile.name?.trim()

  return (
    <div className="space-y-4">
      <header className="px-1 pb-2 pt-4">
        <Label>{longDate(today)}</Label>
        <h1 className="mt-2 font-serif text-[34px] leading-[1.08] tracking-tightish">
          {greeting()}{name ? `, ${name}` : ''}.
        </h1>
      </header>

      {state.sample && (
        <Card className="border-dashed">
          <p className="text-sm">You are exploring with <strong>sample data</strong>. Clear it when you are ready to make the app yours.</p>
          <Button variant="ghost" className="-ml-5 mt-1" onClick={() => dispatch({ type: 'clearSample' })}>Clear sample data</Button>
        </Card>
      )}

      <Card>
        <Label>Today's session</Label>
        <Title className="mt-1">{plan.wod ? plan.wod.name : plan.title}</Title>
        <Muted className="mt-1">{plan.wod ? plan.wod.format : plan.focus}</Muted>
        <div className="mt-2 flex flex-wrap gap-2 text-xs">
          {plan.deload && <span className="rounded-full bg-clay/15 px-3 py-1 text-clay-deep dark:text-clay-soft">Deload week</span>}
          {plan.retest && <span className="rounded-full bg-clay/15 px-3 py-1 text-clay-deep dark:text-clay-soft">Re-test week</span>}
          {plan.cycle && <span className="rounded-full bg-cream-soft px-3 py-1 dark:bg-charcoal-line">{PHASE_LABEL[plan.cycle.phase]} · day {plan.cycle.day}</span>}
        </div>
        {plan.type !== 'rest' && (
          <Button className="mt-4" onClick={() => go('workouts')}>Open session <ArrowRight size={18} /></Button>
        )}
      </Card>

      <Card>
        <div className="flex items-baseline justify-between">
          <Label>Macros today</Label>
          <span className="text-xs text-charcoal/50 dark:text-cream/50">{isTraining ? 'Training-day targets' : 'Rest-day targets'}</span>
        </div>
        <div className="mt-4 space-y-3">
          <Bar label="Protein" value={eaten.protein} target={targets.protein} />
          <Bar label="Carbs" value={eaten.carbs} target={targets.carbs} extra={extra.carbs} />
          <Bar label="Fat" value={eaten.fat} target={targets.fat} extra={extra.fat} />
          <Bar label="Fibre" value={eaten.fibre} target={targets.fibre} />
        </div>
        {(extra.carbs > 0 || extra.fat > 0) && (
          <Muted className="mt-3">Includes a little carried over from yesterday: {extra.carbs} g carbs, {extra.fat} g fat.</Muted>
        )}
        <Button variant="ghost" className="-ml-5 mt-1" onClick={() => go('nutrition')}>Log a meal</Button>
      </Card>

      <Card>
        <Label>This week</Label>
        <ul className="mt-3 grid grid-cols-7 gap-1 text-center">
          {week.map((d) => {
            const t = dayType(state, d)
            const done = state.sessions[d]?.finished
            const isToday = d === today
            return (
              <li key={d} className={`rounded-xl py-2 ${isToday ? 'bg-charcoal text-cream dark:bg-cream dark:text-charcoal' : ''}`}>
                <p className="text-[11px] opacity-60">{dayLetter(d)}</p>
                <p className="mt-1 text-[11px] font-medium">{TYPE_SHORT[t]}</p>
                <p className="mt-1 flex h-4 justify-center">{done && <Check size={14} className="text-clay" />}</p>
              </li>
            )
          })}
        </ul>
      </Card>

      <figure className="px-1 py-4">
        <blockquote className="font-serif text-xl leading-snug">“{quote}”</blockquote>
      </figure>
    </div>
  )
}

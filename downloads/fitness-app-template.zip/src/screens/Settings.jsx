import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { LIFTS } from '../data/profile'
import { todayISO } from '../lib/date'
import { dayType } from '../lib/schedule'
import { Card, Label, Field, inputClass, Button, Muted } from '../components/ui'

function Toggle({ checked, onChange, label }) {
  return (
    <label className="flex items-center justify-between gap-4 py-1 text-[15px]">
      <span>{label}</span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-7 w-12 flex-none rounded-full transition-colors ${checked ? 'bg-clay' : 'bg-cream-line dark:bg-charcoal-line'}`}
      >
        <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${checked ? 'left-6' : 'left-1'}`} />
      </button>
    </label>
  )
}

export default function Settings() {
  const { state, dispatch } = useApp()
  const p = state.profile
  const set = (patch) => dispatch({ type: 'setProfile', patch })
  const today = todayISO()
  const [confirm, setConfirm] = useState(false)

  return (
    <div className="space-y-4">
      <header className="px-1 pt-4">
        <Label>Settings</Label>
        <h1 className="mt-2 font-serif text-[34px] leading-tight tracking-tightish">Make it yours</h1>
      </header>

      <Card>
        <Label>You</Label>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Field label="Your name">
              <input className={inputClass} value={p.name} onChange={(e) => set({ name: e.target.value })} placeholder="Shown on the home screen" />
            </Field>
          </div>
          <Field label="Units">
            <select className={inputClass} value={p.units} onChange={(e) => set({ units: e.target.value })}>
              <option value="kg">kg</option>
              <option value="lbs">lbs</option>
            </select>
          </Field>
          <Field label="Week starts on">
            <select className={inputClass} value={p.weekStart} onChange={(e) => set({ weekStart: +e.target.value })}>
              <option value={1}>Monday</option>
              <option value={0}>Sunday</option>
            </select>
          </Field>
        </div>
      </Card>

      <Card>
        <Label>Training</Label>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Field label="Today's session type">
              <select className={inputClass} value={state.overrides[today] || ''} onChange={(e) => dispatch({ type: 'setOverride', date: today, value: e.target.value })}>
                <option value="">As planned ({dayType({ ...state, overrides: {} }, today)})</option>
                <option value="strength">Strength</option>
                <option value="wod">Conditioning</option>
                <option value="cardio">Cardio</option>
                <option value="rest">Rest</option>
              </select>
            </Field>
          </div>
          <Field label="Weekend cardio">
            <select className={inputClass} value={p.weekendCardio} onChange={(e) => set({ weekendCardio: e.target.value })}>
              <option value="swim">Swim</option>
              <option value="run">Run</option>
            </select>
          </Field>
          <Field label="Pool length (m)">
            <input className={inputClass} inputMode="numeric" value={p.poolLength} onChange={(e) => set({ poolLength: +e.target.value || 25 })} />
          </Field>
          <div className="col-span-2">
            <Field label="Priority lift (an extra set every lifting day)">
              <select className={inputClass} value={p.priorityLift || ''} onChange={(e) => set({ priorityLift: e.target.value || null })}>
                <option value="">None</option>
                {Object.entries(LIFTS).map(([id, n]) => <option key={id} value={id}>{n}</option>)}
              </select>
            </Field>
          </div>
        </div>
        <div className="mt-4 space-y-2">
          <Toggle label="Progression coach (Easy / Grind / Missed)" checked={p.progression} onChange={(v) => set({ progression: v })} />
        </div>
        <Muted className="mt-2">Your training split and workout library live in <code>src/data</code> in the template.</Muted>
      </Card>

      <Card>
        <Label>Macro targets (g)</Label>
        {['training', 'rest'].map((kind) => (
          <div key={kind} className="mt-4">
            <p className="mb-2 text-sm font-medium capitalize">{kind} days</p>
            <div className="grid grid-cols-4 gap-2">
              {['protein', 'carbs', 'fat', 'fibre'].map((m) => (
                <Field key={m} label={m[0].toUpperCase() + m.slice(1)}>
                  <input className={inputClass} inputMode="numeric" value={state.targets[kind][m]} onChange={(e) => dispatch({ type: 'setTargets', kind, patch: { [m]: +e.target.value || 0 } })} />
                </Field>
              ))}
            </div>
          </div>
        ))}
      </Card>

      <Card>
        <Label>Cycle-aware training</Label>
        <div className="mt-3">
          <Toggle label="Ease volume in the luteal phase" checked={p.cycleAware} onChange={(v) => set({ cycleAware: v })} />
        </div>
        {p.cycleAware && (
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Field label="Last cycle start">
              <input className={inputClass} type="date" value={p.cycleStart} onChange={(e) => set({ cycleStart: e.target.value })} />
            </Field>
            <Field label="Cycle length (days)">
              <input className={inputClass} inputMode="numeric" value={p.cycleLength} onChange={(e) => set({ cycleLength: +e.target.value || 28 })} />
            </Field>
          </div>
        )}
        <Muted className="mt-3">Optional and off by default. When on, prescribed volume eases by about 12% in the luteal phase and hard sessions are marked moderate. Stored only on this phone.</Muted>
      </Card>

      <Card>
        <Label>Your data</Label>
        <Muted className="mt-2">Everything you enter, including body measurements, progress photos and cycle dates, is stored in this browser on this phone. Nothing is sent to me or to anyone else: no account, no analytics, no cookies.</Muted>
        <Muted className="mt-2">The app is hosted on GitHub, which logs visitors' IP addresses for security. There is no cloud backup, so clearing Safari's website data or tapping Reset all data erases everything for good.</Muted>
        <div className="mt-4 flex flex-wrap gap-2">
          {!state.sample && <Button variant="quiet" onClick={() => dispatch({ type: 'loadSample' })}>Load sample data</Button>}
          {state.sample && <Button variant="quiet" onClick={() => dispatch({ type: 'clearSample' })}>Clear sample data</Button>}
          {!confirm ? (
            <Button variant="quiet" onClick={() => setConfirm(true)}>Reset all data</Button>
          ) : (
            <span className="flex items-center gap-2">
              <Button onClick={() => { dispatch({ type: 'reset' }); setConfirm(false) }}>Yes, erase everything</Button>
              <Button variant="ghost" onClick={() => setConfirm(false)}>Cancel</Button>
            </span>
          )}
        </div>
      </Card>

      <p className="px-1 pb-4 text-center text-xs text-charcoal/50 dark:text-cream/50">
        A template by <a className="underline" href="https://milena-boc.github.io" target="_blank" rel="noopener">Milena Boc</a>, built with Claude.
      </p>
    </div>
  )
}

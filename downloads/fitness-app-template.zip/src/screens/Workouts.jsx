import { useApp } from '../context/AppContext'
import { planFor } from '../lib/schedule'
import { todayISO } from '../lib/date'
import SessionDetail from '../components/SessionDetail'
import WodLibrary from '../components/WodLibrary'
import PRLog from '../components/PRLog'
import Timer from '../components/Timer'
import { Pill, Label } from '../components/ui'

const SUBTABS = [
  ['today', 'Today'],
  ['library', 'Library'],
  ['prs', 'PR log'],
  ['timer', 'Timer']
]

export default function Workouts({ sub, setSub, timer, openTimer }) {
  const { state } = useApp()
  const plan = planFor(state, todayISO())
  return (
    <div className="space-y-4">
      <header className="px-1 pt-4">
        <Label>Train</Label>
        <h1 className="mt-2 font-serif text-[34px] leading-tight tracking-tightish">Workouts</h1>
      </header>
      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
        {SUBTABS.map(([id, l]) => <Pill key={id} active={sub === id} onClick={() => setSub(id)}>{l}</Pill>)}
      </div>
      {sub === 'today' && <SessionDetail plan={plan} onOpenTimer={openTimer} />}
      {sub === 'library' && <WodLibrary onOpenTimer={openTimer} />}
      {sub === 'prs' && <PRLog />}
      {sub === 'timer' && <Timer preset={timer.preset} title={timer.title} />}
    </div>
  )
}

import { useMemo, useState } from 'react'
import { X } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { FOODS } from '../data/foods'
import { dayType } from '../lib/schedule'
import { todayISO, addDays } from '../lib/date'
import { macrosFor, sumMeals, carryOver, kcal } from '../lib/nutrition'
import { Card, Label, Bar, Button, Field, inputClass, Muted, Pill } from '../components/ui'

export default function Nutrition() {
  const { state, dispatch } = useApp()
  const [view, setView] = useState('log')
  const [foodId, setFoodId] = useState(FOODS[0].id)
  const [grams, setGrams] = useState('')
  const today = todayISO()
  const isTraining = dayType(state, today) !== 'rest'
  const targets = state.targets[isTraining ? 'training' : 'rest']
  const yesterday = addDays(today, -1)
  const yType = dayType(state, yesterday) !== 'rest' ? 'training' : 'rest'
  const extra = carryOver(state.targets[yType], state.meals[yesterday] ? sumMeals(state.meals[yesterday]) : null, targets)
  const meals = state.meals[today] || []
  const eaten = sumMeals(meals)
  const food = FOODS.find((f) => f.id === foodId)
  const preview = useMemo(() => (grams > 0 ? macrosFor(food, +grams) : null), [food, grams])

  const add = () => {
    if (!preview) return
    dispatch({ type: 'addMeal', date: today, meal: { foodId, name: food.name, grams: +grams, ...preview } })
    setGrams('')
  }

  return (
    <div className="space-y-4">
      <header className="px-1 pt-4">
        <Label>Eat</Label>
        <h1 className="mt-2 font-serif text-[34px] leading-tight tracking-tightish">Nutrition</h1>
      </header>
      <div className="flex gap-2">
        <Pill active={view === 'log'} onClick={() => setView('log')}>Today</Pill>
        <Pill active={view === 'guide'} onClick={() => setView('guide')}>Macro guide</Pill>
      </div>

      {view === 'log' && (
        <>
          <Card>
            <div className="flex items-baseline justify-between">
              <Label>Macro snapshot</Label>
              <span className="text-xs tabular-nums text-charcoal/50 dark:text-cream/50">{kcal(eaten)} kcal</span>
            </div>
            <div className="mt-4 space-y-3">
              <Bar label="Protein" value={eaten.protein} target={targets.protein} />
              <Bar label="Carbs" value={eaten.carbs} target={targets.carbs} extra={extra.carbs} />
              <Bar label="Fat" value={eaten.fat} target={targets.fat} extra={extra.fat} />
              <Bar label="Fibre" value={eaten.fibre} target={targets.fibre} />
            </div>
            <Muted className="mt-3">{isTraining ? 'Training-day' : 'Rest-day'} targets. Change them in Settings.</Muted>
          </Card>

          <Card>
            <Label>Log a meal</Label>
            <div className="mt-3 grid grid-cols-[1fr_96px] gap-3">
              <Field label="Food">
                <select className={inputClass} value={foodId} onChange={(e) => setFoodId(e.target.value)}>
                  {FOODS.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                </select>
              </Field>
              <Field label="Grams">
                <input className={inputClass} inputMode="numeric" value={grams} onChange={(e) => setGrams(e.target.value.replace(/[^0-9.]/g, ''))} placeholder="0" />
              </Field>
            </div>
            {preview && (
              <p className="mt-3 text-sm tabular-nums text-charcoal/70 dark:text-cream/70">
                {preview.protein} g protein · {preview.carbs} g carbs · {preview.fat} g fat · {preview.fibre} g fibre
              </p>
            )}
            <Button className="mt-4" onClick={add} disabled={!preview}>Add to today</Button>
          </Card>

          <Card>
            <Label>Today's meals</Label>
            {meals.length === 0 ? (
              <Muted className="mt-3">Nothing logged yet today.</Muted>
            ) : (
              <ul className="mt-2">
                {meals.map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-3 border-t border-cream-line py-3 first:border-t-0 dark:border-charcoal-line">
                    <div>
                      <p className="text-[15px]">{m.name} <span className="text-charcoal/50 dark:text-cream/50">· {m.grams} g</span></p>
                      <p className="text-xs tabular-nums text-charcoal/50 dark:text-cream/50">P {m.protein} · C {m.carbs} · F {m.fat} · Fi {m.fibre}</p>
                    </div>
                    <button type="button" aria-label={`Remove ${m.name}`} onClick={() => dispatch({ type: 'removeMeal', date: today, id: m.id })}>
                      <X size={16} />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </>
      )}

      {view === 'guide' && (
        <Card>
          <Label>Per 100 g</Label>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-sm tabular-nums">
              <thead>
                <tr className="text-left text-xs text-charcoal/50 dark:text-cream/50">
                  <th className="py-2 pr-2 font-normal">Food</th>
                  <th className="px-1 text-right font-normal">P</th>
                  <th className="px-1 text-right font-normal">C</th>
                  <th className="px-1 text-right font-normal">F</th>
                  <th className="pl-1 text-right font-normal">Fi</th>
                </tr>
              </thead>
              <tbody>
                {FOODS.map((f) => (
                  <tr key={f.id} className="border-t border-cream-line dark:border-charcoal-line">
                    <td className="py-2 pr-2">{f.name}</td>
                    <td className="px-1 text-right">{f.protein}</td>
                    <td className="px-1 text-right">{f.carbs}</td>
                    <td className="px-1 text-right">{f.fat}</td>
                    <td className="pl-1 text-right">{f.fibre}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Muted className="mt-3">Approximate values. Check your own labels.</Muted>
        </Card>
      )}
    </div>
  )
}

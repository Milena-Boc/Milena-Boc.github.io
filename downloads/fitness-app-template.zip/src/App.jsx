import { useState } from 'react'
import { useApp } from './context/AppContext'
import TabBar from './components/TabBar'
import Welcome from './components/Welcome'
import Home from './screens/Home'
import Workouts from './screens/Workouts'
import Nutrition from './screens/Nutrition'
import Progress from './screens/Progress'
import Settings from './screens/Settings'

export default function App() {
  const { state } = useApp()
  const [tab, setTab] = useState('home')
  const [sub, setSub] = useState('today')
  const [timer, setTimer] = useState({ preset: null, title: '' })

  const go = (t, s) => {
    setTab(t)
    if (s) setSub(s)
    window.scrollTo(0, 0)
  }
  const openTimer = (preset, title) => {
    setTimer({ preset: { ...preset }, title })
    go('workouts', 'timer')
  }

  return (
    <div className="min-h-screen" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <main className="mx-auto max-w-md px-4 pb-28">
        {tab === 'home' && <Home go={(t) => go(t, t === 'workouts' ? 'today' : undefined)} />}
        {tab === 'workouts' && <Workouts sub={sub} setSub={setSub} timer={timer} openTimer={openTimer} />}
        {tab === 'nutrition' && <Nutrition />}
        {tab === 'progress' && <Progress />}
        {tab === 'settings' && <Settings />}
      </main>
      <TabBar tab={tab} setTab={(t) => go(t)} />
      {!state.welcomed && <Welcome />}
    </div>
  )
}

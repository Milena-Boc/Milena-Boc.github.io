// Sample data so a first-time visitor can see the app working.
// It is clearly labelled in the app and can be cleared in one tap.
import { addDays, todayISO } from '../lib/date'

export function sampleData() {
  const t = todayISO()
  const d = (n) => addDays(t, n)
  return {
    prs: {
      backSquat: [{ date: d(-60), kg: 75 }, { date: d(-20), kg: 80 }],
      frontSquat: [{ date: d(-40), kg: 65 }],
      deadlift: [{ date: d(-50), kg: 95 }, { date: d(-12), kg: 100 }],
      romanianDeadlift: [{ date: d(-30), kg: 80 }],
      benchPress: [{ date: d(-45), kg: 50 }],
      strictPress: [{ date: d(-35), kg: 35 }],
      pushPress: [{ date: d(-35), kg: 45 }],
      powerClean: [{ date: d(-25), kg: 55 }],
      snatch: [{ date: d(-25), kg: 40 }],
      hipThrust: [{ date: d(-15), kg: 100 }]
    },
    body: [
      { date: d(-84), weight: 64.0, muscle: 26.8, fatMass: 16.0, fatPct: 25.0, visceral: 5, bmi: 23.1 },
      { date: d(-56), weight: 63.6, muscle: 27.1, fatMass: 15.2, fatPct: 23.9, visceral: 5, bmi: 23.0 },
      { date: d(-28), weight: 63.1, muscle: 27.5, fatMass: 14.3, fatPct: 22.7, visceral: 4, bmi: 22.8 },
      { date: d(-1), weight: 62.9, muscle: 27.9, fatMass: 13.6, fatPct: 21.6, visceral: 4, bmi: 22.7 }
    ],
    meals: {
      [t]: [
        { id: 's1', foodId: 'oats', name: 'Oats, dry', grams: 60, protein: 7.8, carbs: 39.6, fat: 4.2, fibre: 6 },
        { id: 's2', foodId: 'yoghurt', name: 'Greek yoghurt, 0%', grams: 200, protein: 20, carbs: 7.2, fat: 0.8, fibre: 0 },
        { id: 's3', foodId: 'chicken', name: 'Chicken breast, cooked', grams: 150, protein: 46.5, carbs: 0, fat: 5.4, fibre: 0 }
      ]
    },
    sessions: {
      [d(-1)]: { started: true, finished: true },
      [d(-2)]: { started: true, finished: true },
      [d(-4)]: { started: true, finished: true }
    }
  }
}

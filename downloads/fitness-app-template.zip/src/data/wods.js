// [YOUR WORKOUTS]. A library of classic CrossFit benchmarks plus strength formats.
// Swap these for your own style: running intervals, swim sets, yoga or pilates flows.
//
// timer: { mode: 'fortime', cap } | { mode: 'amrap', minutes } | { mode: 'emom', minutes, interval }
// load:  { lift, pct } prescribes a weight from your PR (conditioning 60 to 70%).

export const WODS = [
  { id: 'fran', name: 'Fran', format: '21-15-9, for time', timer: { mode: 'fortime', cap: 10 },
    work: ['Thrusters', 'Pull-ups'], load: { lift: 'frontSquat', pct: 0.6, label: 'Thrusters' } },
  { id: 'grace', name: 'Grace', format: '30 clean and jerks, for time', timer: { mode: 'fortime', cap: 10 },
    work: ['30 clean and jerks'], load: { lift: 'powerClean', pct: 0.65, label: 'Clean and jerk' } },
  { id: 'helen', name: 'Helen', format: '3 rounds, for time', timer: { mode: 'fortime', cap: 15 },
    work: ['400 m run', '21 kettlebell swings', '12 pull-ups'] },
  { id: 'annie', name: 'Annie', format: '50-40-30-20-10, for time', timer: { mode: 'fortime', cap: 15 },
    work: ['Double-unders', 'Sit-ups'] },
  { id: 'chelsea', name: 'Chelsea', format: 'Every minute for 20 minutes', timer: { mode: 'emom', minutes: 20, interval: 60 },
    work: ['5 pull-ups', '10 push-ups', '15 air squats'] },
  { id: 'cindy', name: 'Cindy', format: 'As many rounds as possible in 20 minutes', timer: { mode: 'amrap', minutes: 20 },
    work: ['5 pull-ups', '10 push-ups', '15 air squats'] },
  { id: 'diane', name: 'Diane', format: '21-15-9, for time', timer: { mode: 'fortime', cap: 12 },
    work: ['Deadlifts', 'Handstand push-ups (or pike push-ups)'], load: { lift: 'deadlift', pct: 0.65, label: 'Deadlifts' } },
  { id: 'elizabeth', name: 'Elizabeth', format: '21-15-9, for time', timer: { mode: 'fortime', cap: 12 },
    work: ['Cleans', 'Ring dips (or bench dips)'], load: { lift: 'powerClean', pct: 0.65, label: 'Cleans' } },
  { id: 'isabel', name: 'Isabel', format: '30 snatches, for time', timer: { mode: 'fortime', cap: 10 },
    work: ['30 snatches'], load: { lift: 'snatch', pct: 0.65, label: 'Snatches' } },
  { id: 'jackie', name: 'Jackie', format: 'For time', timer: { mode: 'fortime', cap: 15 },
    work: ['1,000 m row', '50 thrusters (light bar)', '30 pull-ups'], load: { lift: 'frontSquat', pct: 0.35, label: 'Thrusters' } },
  { id: 'karen', name: 'Karen', format: '150 wall balls, for time', timer: { mode: 'fortime', cap: 15 },
    work: ['150 wall balls'] },
  { id: 'nancy', name: 'Nancy', format: '5 rounds, for time', timer: { mode: 'fortime', cap: 20 },
    work: ['400 m run', '15 overhead squats'], load: { lift: 'snatch', pct: 0.6, label: 'Overhead squats' } },
  { id: 'mary', name: 'Mary', format: 'As many rounds as possible in 20 minutes', timer: { mode: 'amrap', minutes: 20 },
    work: ['5 handstand push-ups (or pike push-ups)', '10 alternating pistols (or box step-ups)', '15 pull-ups'] },
  { id: 'dt', name: 'DT', format: '5 rounds, for time', timer: { mode: 'fortime', cap: 20 },
    work: ['12 deadlifts', '9 hang power cleans', '6 push jerks'], load: { lift: 'deadlift', pct: 0.55, label: 'One bar, all three lifts' } },
  { id: 'barbara', name: 'Barbara', format: '5 rounds, for time, 3 minutes rest between rounds', timer: { mode: 'fortime', cap: 40 },
    work: ['20 pull-ups', '30 push-ups', '40 sit-ups', '50 air squats'] },
  { id: 'kelly', name: 'Kelly', format: '5 rounds, for time', timer: { mode: 'fortime', cap: 40 },
    work: ['400 m run', '30 box jumps', '30 wall balls'] },
  { id: 'emom-clean', name: 'Clean EMOM', format: 'Strength · every minute for 10 minutes', timer: { mode: 'emom', minutes: 10, interval: 60 },
    work: ['3 power cleans, crisp and fast'], load: { lift: 'powerClean', pct: 0.75, label: 'Power cleans' } },
  { id: 'front-e2', name: 'Front squat waves', format: 'Strength · every 2 minutes for 12 minutes', timer: { mode: 'emom', minutes: 12, interval: 120 },
    work: ['5 front squats'], load: { lift: 'frontSquat', pct: 0.75, label: 'Front squats' } },
  { id: 'pull-couplet', name: 'Pull couplet', format: 'Strength · 4 rounds for quality', timer: { mode: 'fortime', cap: 16 },
    work: ['8 deadlifts', '10 bent-over rows', 'Rest 90 seconds'], load: { lift: 'deadlift', pct: 0.7, label: 'Deadlifts and rows' } },
  { id: 'kb-amrap', name: 'Bell and burpee', format: 'As many rounds as possible in 12 minutes', timer: { mode: 'amrap', minutes: 12 },
    work: ['10 kettlebell swings', '8 goblet squats', '6 burpees'] },
  { id: 'row-push', name: 'Row and push', format: 'Every minute for 16 minutes, alternating', timer: { mode: 'emom', minutes: 16, interval: 60 },
    work: ['Odd minutes: 12 calorie row', 'Even minutes: 10 push-ups'] },
  { id: 'twenty', name: 'Twenty', format: 'Chipper, for time', timer: { mode: 'fortime', cap: 20 },
    work: ['20 wall balls', '20 kettlebell swings', '20 box jumps', '20 push presses', '20 sit-ups', '20 burpees'], load: { lift: 'pushPress', pct: 0.5, label: 'Push presses' } }
]

export const WARMUPS = {
  strength: ['3 minutes easy row or bike', '10 air squats, 10 hip bridges, 10 band pull-aparts', '2 ramp-up sets of your first lift: 5 reps at 40%, 3 at 60%'],
  wod: ['4 minutes easy cardio', '2 rounds: 10 lunges, 5 inchworms, 10 kettlebell deadlifts', 'One practice round of the workout at half pace'],
  cardio: ['5 minutes easy pace', '4 short pick-ups of 20 seconds'],
  rest: ['A 20 to 30 minute walk']
}

export const COOLDOWNS = {
  strength: ['90 seconds per side: couch stretch', '1 minute: hanging or supported shoulder stretch', '2 minutes slow breathing'],
  wod: ['3 minutes easy walk', '1 minute per side: pigeon stretch', '1 minute: child’s pose'],
  cardio: ['5 minutes easy', 'Calves and hip flexors, 1 minute each side'],
  rest: ['10 minutes of yoga or pilates mobility, if you feel like it']
}

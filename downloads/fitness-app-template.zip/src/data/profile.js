// ─────────────────────────────────────────────────────────────
// MAKE IT YOURS
// Everything personal lives in this folder. Most settings can also be
// changed inside the app, under Settings.
// ─────────────────────────────────────────────────────────────

export const DEFAULT_PROFILE = {
  name: '', // [YOUR NAME], shown on Home. Set it in Settings.
  units: 'kg', // 'kg' or 'lbs'
  weekStart: 1, // 0 = Sunday, 1 = Monday
  weekendCardio: 'swim', // 'swim' or 'run'
  poolLength: 25, // metres
  priorityLift: 'hipThrust', // a lift that gets an extra set every lifting day, or null
  progression: true, // the Easy / Grind / Missed coach layer
  cycleAware: false, // optional: eases volume in the luteal phase
  cycleStart: '', // YYYY-MM-DD
  cycleLength: 28,
  blockStart: null // set automatically on first launch
}

// The standard lifts the app knows. Add your own in the PR log.
export const LIFTS = {
  backSquat: 'Back squat',
  frontSquat: 'Front squat',
  deadlift: 'Deadlift',
  romanianDeadlift: 'Romanian deadlift',
  benchPress: 'Bench press',
  strictPress: 'Strict press',
  pushPress: 'Push press',
  powerClean: 'Power clean',
  snatch: 'Power snatch',
  hipThrust: 'Hip thrust'
}

// [YOUR WEEKLY SPLIT]. Keys are weekdays: 0 = Sunday ... 6 = Saturday.
// type: 'strength' | 'wod' | 'cardio' | 'rest'
export const SPLIT = {
  1: { type: 'strength', key: 'A', title: 'Strength A', focus: 'Lower body' },
  2: { type: 'wod', title: 'Conditioning', focus: 'Benchmark workout' },
  3: { type: 'strength', key: 'B', title: 'Strength B', focus: 'Upper body' },
  4: { type: 'wod', title: 'Conditioning', focus: 'Benchmark workout' },
  5: { type: 'strength', key: 'C', title: 'Strength C', focus: 'Full body' },
  6: { type: 'cardio', title: 'Long cardio', focus: 'Swim or run' },
  0: { type: 'rest', title: 'Rest', focus: 'Walk, mobility, recover' }
}

// Main lifts per strength day. pct = share of your one-rep max (75 to 85%).
export const STRENGTH_DAYS = {
  A: [
    { lift: 'backSquat', sets: 4, reps: 5, pct: 0.8 },
    { lift: 'romanianDeadlift', sets: 3, reps: 8, pct: 0.75 }
  ],
  B: [
    { lift: 'benchPress', sets: 4, reps: 5, pct: 0.8 },
    { lift: 'strictPress', sets: 3, reps: 6, pct: 0.75 }
  ],
  C: [
    { lift: 'deadlift', sets: 3, reps: 5, pct: 0.8 },
    { lift: 'frontSquat', sets: 3, reps: 6, pct: 0.75 }
  ]
}

// Macro targets in grams. Training days and rest days can differ.
export const DEFAULT_TARGETS = {
  training: { protein: 120, carbs: 200, fat: 60, fibre: 30 }, // [YOUR TARGETS]
  rest: { protein: 120, carbs: 150, fat: 65, fibre: 30 }
}

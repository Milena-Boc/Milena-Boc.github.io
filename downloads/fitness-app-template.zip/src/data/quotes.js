// [YOUR QUOTES]. One appears on Home each day. Replace them with lines that move you.
export const QUOTES = [
  'Show up first. Motivation usually arrives during the warm-up.',
  'Small, boring, repeated. That is how strong is built.',
  'You are allowed to go lighter today and still count it.',
  'Consistency beats intensity you cannot repeat.',
  'Eat like someone who trains. Rest like someone who means it.',
  'The bar does not care about your week. That is the gift.',
  'Good form is the fastest route to heavy.',
  'Progress hides in the logbook. Write it down.',
  'A deload is part of the plan, not a pause in it.',
  'Breathe. Brace. Begin.',
  'Strong is a practice, not a destination.',
  'Finish the session you planned, not the one you imagined.',
  'Today counts, even when it is quiet.',
  'Recovery is training you cannot see.'
]

// [YOUR FOODS]. Approximate values per 100 g. Check your own labels and add your favourites.
export const FOODS = [
  { id: 'chicken', name: 'Chicken breast, cooked', protein: 31, carbs: 0, fat: 3.6, fibre: 0 },
  { id: 'salmon', name: 'Salmon, cooked', protein: 22, carbs: 0, fat: 12, fibre: 0 },
  { id: 'beef', name: 'Lean beef mince, cooked', protein: 26, carbs: 0, fat: 9, fibre: 0 },
  { id: 'eggs', name: 'Eggs', protein: 13, carbs: 1.1, fat: 11, fibre: 0 },
  { id: 'tofu', name: 'Tofu, firm', protein: 15, carbs: 2, fat: 9, fibre: 2 },
  { id: 'lentils', name: 'Lentils, cooked', protein: 9, carbs: 20, fat: 0.4, fibre: 8 },
  { id: 'yoghurt', name: 'Greek yoghurt, 0%', protein: 10, carbs: 3.6, fat: 0.4, fibre: 0 },
  { id: 'cottage', name: 'Cottage cheese', protein: 11, carbs: 3.4, fat: 4.3, fibre: 0 },
  { id: 'whey', name: 'Whey protein powder', protein: 80, carbs: 8, fat: 6, fibre: 0 },
  { id: 'oats', name: 'Oats, dry', protein: 13, carbs: 66, fat: 7, fibre: 10 },
  { id: 'rice', name: 'White rice, cooked', protein: 2.7, carbs: 28, fat: 0.3, fibre: 0.4 },
  { id: 'pasta', name: 'Pasta, cooked', protein: 5.8, carbs: 31, fat: 0.9, fibre: 1.8 },
  { id: 'sweetpotato', name: 'Sweet potato, cooked', protein: 2, carbs: 20, fat: 0.1, fibre: 3.3 },
  { id: 'bread', name: 'Wholemeal bread', protein: 10, carbs: 42, fat: 2.5, fibre: 7 },
  { id: 'banana', name: 'Banana', protein: 1.1, carbs: 23, fat: 0.3, fibre: 2.6 },
  { id: 'blueberries', name: 'Blueberries', protein: 0.7, carbs: 14, fat: 0.3, fibre: 2.4 },
  { id: 'broccoli', name: 'Broccoli', protein: 2.8, carbs: 7, fat: 0.4, fibre: 2.6 },
  { id: 'avocado', name: 'Avocado', protein: 2, carbs: 9, fat: 15, fibre: 7 },
  { id: 'almonds', name: 'Almonds', protein: 21, carbs: 22, fat: 50, fibre: 12.5 },
  { id: 'oliveoil', name: 'Olive oil', protein: 0, carbs: 0, fat: 100, fibre: 0 }
]

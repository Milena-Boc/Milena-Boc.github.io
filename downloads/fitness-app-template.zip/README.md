# Fitness & Nutrition

A personal, offline-first fitness and nutrition app for one person. Add it to your phone's home screen, use it offline after the first load, and keep **all of your data on your own device**. No backend, no account, no external API.

Built with **React, Vite and Tailwind CSS**, with an editorial design and **Lucide** icons.

> Designed by [Milena Boc](https://milena-boc.github.io) and built with Claude. Shared as a template so you can make it yours.

**Try it:** [milena-boc.github.io/fitness-app](https://milena-boc.github.io/fitness-app/). Open it in Safari on your iPhone, tap **Share**, then **Add to Home Screen**. Your data stays on your phone.

---

## What's inside

- **Today**: the date, today's session, your macro targets, your training week and a daily line.
- **Train**
  - A weekly split that resolves automatically from the day of the week: strength, conditioning, cardio and rest days.
  - A **library of 22 workouts**: classic CrossFit benchmarks (Fran, Grace, Helen, Annie, Chelsea, Cindy, Diane, Elizabeth, Isabel, Jackie, Karen, Nancy, Mary, DT, Barbara, Kelly) plus strength formats, rotated week to week.
  - Every session has a **warm-up**, the **main work** and a **cool-down and mobility** block.
  - A **workout timer**: AMRAP countdown, EMOM with a beep each interval, and For Time with a cap. It uses the Web Audio API, so there are no audio files.
  - **Prescribed weights** in kg or lbs, calculated from your personal records (strength at 75 to 85% of your one-rep max, conditioning at 60 to 70%). Update a PR and every weight recalculates.
  - A **PR log** for the standard lifts plus your own custom lifts.
  - **Start and finish** each session. Logging a top set estimates your one-rep max (Epley formula) and updates your PR if you beat it, from the next day.
  - A **progression coach**: rate each main lift *Easy, Grind or Missed* to set next week's target. Strength lifts move load; your **priority lift** moves reps from 8 to 12, then adds load. A 4-week block inserts a **deload week** and flags a **re-test week** at the start of each new block.
- **Eat**
  - A **macro snapshot** for protein, carbs, fat and fibre, with separate training-day and rest-day targets, and a small carry-over of yesterday's unfinished carbs and fat.
  - Meal logging from a **built-in food list** that calculates macros from the grams you enter.
  - A **macro guide**: a quick reference table for the kitchen.
- **Progress**
  - **Body-composition logging**: weight, muscle mass, body-fat mass, body-fat %, visceral fat and BMI, with a line chart per metric.
  - **Monthly progress photos**, downscaled and stored on the phone only.
- **Settings**: your name, units, week start, weekend cardio (swim or run) and pool length, today's session type, your priority lift, macro targets, sample data and a full reset.
- **Optional, off by default**: cycle-aware training, which eases prescribed volume by about 12% in the luteal phase.

---

## Make it yours

Most things can be changed in **Settings** inside the app. To change the training itself, edit the files in `src/data/`:

| File | What to change |
| :-- | :-- |
| `src/data/profile.js` | Your weekly split, the lifts on each strength day, your priority lift, default macro targets |
| `src/data/wods.js` | Your workout library, warm-ups and cool-downs. Swap in running intervals, swim sets, yoga or pilates flows |
| `src/data/foods.js` | Your foods, with macros per 100 g |
| `src/data/quotes.js` | The daily lines on the home screen |
| `src/data/sample.js` | The sample data a first-time visitor can explore |

Your personal records, meals, body-composition entries and photos are entered in the app and never leave your phone.

---

## Run it on your computer

Requires **Node 18 or newer**.

```bash
npm install
npm run dev
```

Open the address it prints (for example `http://localhost:5173`).

To build the offline-ready version:

```bash
npm run build
```

The finished app is in `dist/`. App icons are generated with `python3 scripts/gen_icons.py`.

---

## Put it on your iPhone

iOS installs web apps from **Safari**, and offline use needs **HTTPS**.

1. Run `npm run build`.
2. Upload the `dist/` folder to any free static host: Netlify (drag and drop), Vercel, or GitHub Pages.
3. On your iPhone, open the address in **Safari**.
4. Tap **Share**, then **Add to Home Screen**, then **Add**.
5. Open it from your home screen. After the first load it works offline.

---

## Data and privacy

Everything lives in your browser's `localStorage`, including progress photos as small compressed images. Nothing is sent anywhere. Clearing Safari's website data, or tapping **Reset all data** in Settings, erases it. There is no cloud backup, by design.

---

## Tech notes

- **Stack**: React 18, Vite 5, Tailwind 3, `vite-plugin-pwa` (Workbox) for offline caching, `lucide-react` for icons.
- **Charts**: a small custom SVG line chart, no chart library.
- **Fonts**: system fonts only, so nothing needs downloading.
- **Light and dark**: follows your phone's setting.

```
src/
  data/        your split, workouts, foods, quotes and sample data  ← edit these
  lib/         dates, schedule, weights, progression, cycle, nutrition, storage
  context/     app state, saved to localStorage
  components/  tab bar, timer, line chart, session, PR log, workout library
  screens/     Today, Train, Eat, Progress, Settings
```

The values in the food list are approximate. This app is a training log, not medical or nutritional advice.

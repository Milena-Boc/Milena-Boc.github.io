"""Generate the app icons (no dependencies beyond Pillow). Run: python3 scripts/gen_icons.py"""
from PIL import Image, ImageDraw
import os
out = os.path.join(os.path.dirname(__file__), '..', 'public')
def icon(size):
    im = Image.new('RGB', (size, size), '#141414')
    d = ImageDraw.Draw(im)
    s = size / 512
    # a simple barbell mark in terracotta
    d.rounded_rectangle([96*s, 244*s, 416*s, 268*s], radius=10*s, fill='#C0795C')
    for x in (136, 176, 336, 376):
        h = 120 if x in (176, 336) else 84
        d.rounded_rectangle([(x-14)*s, (256-h/2)*s, (x+14)*s, (256+h/2)*s], radius=8*s, fill='#F4F1EA')
    return im
for size, name in [(192, 'icon-192.png'), (512, 'icon-512.png'), (180, 'apple-touch-icon.png')]:
    icon(size).save(os.path.join(out, name))
print('icons written')
